
const APP = {
  key: "cashgo_user",
  init(){
    const saved = localStorage.getItem(this.key);
    if(saved){ this.data = JSON.parse(saved); }
    else { this.data = { username:"Gaetano", points:0 }; this.save(); }
    this.render();
  },
  save(){ localStorage.setItem(this.key, JSON.stringify(this.data)); },
  addPoints(n){
    this.data.points += n;
    this.save();
    alert("Hai ottenuto +" + n + " punti!");
    this.render();
  },
  render(){
    document.getElementById("app").innerHTML = `
      <div class='card'>
        <h2>Ciao, ${this.data.username}</h2>
        <p>Punti: <b>${this.data.points}</b></p>
      </div>
      <div class='card'>
        <a class='btn' href='#' onclick='APP.addPoints(20)'>Guarda Video (+20)</a>
      </div>
    `;
  }
};
window.onload = ()=>APP.init();
